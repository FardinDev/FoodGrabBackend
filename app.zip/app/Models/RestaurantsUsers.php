<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RestaurantsUsers extends Model
{
    use HasFactory;

    protected $table = 'restaurants_users';
}
